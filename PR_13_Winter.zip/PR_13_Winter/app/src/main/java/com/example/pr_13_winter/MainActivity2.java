package com.example.pr_13_winter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity2 extends Activity implements View.OnClickListener{


    ImageButton one;
    ImageButton two;
    ImageButton three;
    ImageButton four;

    ImageView imageView16;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        one = findViewById(R.id.imageButton6);
        one.setOnClickListener(this);
        two = findViewById(R.id.imageButton2);
        two.setOnClickListener(this);
        three = findViewById(R.id.imageButton3);
        three.setOnClickListener(this);
        four = findViewById(R.id.imageButton4);
        four.setOnClickListener(this);

        imageView16=findViewById(R.id.imageView16);
        imageView16.setOnClickListener(this);

    }
    public void onClick(View view){
        switch (view.getId()) {
            case R.id.imageButton6:
                Toast.makeText(this, "Спокойным", Toast.LENGTH_SHORT).show();break;
            case R.id.imageButton2:
                Toast.makeText(this, "Расслабленным", Toast.LENGTH_SHORT).show();break;
            case R.id.imageButton3:
                Toast.makeText(this, "Сосредоточенным", Toast.LENGTH_SHORT).show();break;
            case R.id.imageButton4:
                Toast.makeText(this, "Взволнованным", Toast.LENGTH_SHORT).show();
                break;
        }

    }
    public void onClickimage(View view){
        Intent intent = new Intent(this, profile.class);
        startActivity(intent);

    }

}